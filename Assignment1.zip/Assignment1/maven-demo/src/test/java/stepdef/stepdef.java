package stepdef;


import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class stepdef {
	
// unable to map with test steps written in GHERKIN language( configuration issue )
    @Given("^user sets the base API request$")
    public void user_sets_the_base_API_request() {
	RestAssured.baseURI="http://localhost:8081/api/v1/users/all";
	 
}
	
	@When("a client app attempts to request user with admin details")
	public void a_client_app_attempts_to_request_user_with_admin_details() {
		RequestSpecification httpRequest= RestAssured.given().param("username", "admin"); 
	}

	@Then("the response should be a JSON object")
	public void the_response_should_be_a_JSON_object1() {
		RequestSpecification httpRequest= RestAssured.given().param("username", "admin"); 
		httpRequest.header("Content-Type","application/json"); 
		Response response = httpRequest.request(Method.GET,""); 
		String output= response.getBody().asString(); 
		int statusCode = response.getStatusCode();
		System.out.println("statusCode"+statusCode);
	}


	//@Given("^user sets the base API request$")
	//public void usersetsthebaseAPIrequest(String URL)
	//RestAssured.baseURI="http://localhost:8081/api/v1/users/details?username=";
	//RestAssured.baseURI=URL; 
	
	///////////NOTE////////////
	//perform execution by @Test annotations - Testng
	
	
	@Test
	public void GetUserInfo()
	
	{
	RestAssured.baseURI="http://localhost:8081/api/v1/users/details?username="; 
	RequestSpecification httpRequest= RestAssured.given().param("username", "tester"); 
	httpRequest.header("Content-Type","application/json"); 
	Response response = httpRequest.request(Method.GET,""); 
	String output= response.getBody().asString(); 
	System.out.println("ResponseBody"+output); 
	int statusCode = response.getStatusCode(); 
	System.out.println("statusCode-"+statusCode);
	
}
	
	
	public void GetAllUserInfo()
	{	
		
		RestAssured.baseURI="http://localhost:8081/api/v1/users/all"; 
		RequestSpecification httpRequest= RestAssured.given().auth().preemptive().basic("admin","power");
		httpRequest.header("Content-Type","application/json"); 
		Response response = httpRequest.request(Method.GET,""); 
		String output= response.getBody().asString(); 
		System.out.println("ResponseBody"+output); 
		int statusCode = response.getStatusCode(); 
		System.out.println("statusCode--"+statusCode);
	}
	
		
		public void Login()
		{	
			
			RestAssured.baseURI="http://localhost:8081/api/v1/users/access"; 
			RequestSpecification httpRequest= RestAssured.given().auth().preemptive().basic("dev","wizard");
			httpRequest.header("Content-Type","application/json"); 
			Response response = httpRequest.request(Method.GET,""); 
			String output= response.getBody().asString(); 
			System.out.println("ResponseBody"+output); 
			int statusCode = response.getStatusCode(); 
			System.out.println("statusCode---"+statusCode);
		    Assert.assertEquals(200, statusCode);
		    
	
	}
		
		
		public void SignupPOST()
		{	
			RestAssured.baseURI = "http://localhost:8081/api/v1/users"; 
		RequestSpecification httpRequest = RestAssured.given();
			JSONObject json = new JSONObject();  
			json.put("id", "1"); 
			json.put("email", "admin2@somewhere.com");
			json.put("username", "admin2"); 
			json.put("password", "admin2"); 
			json.put("name", "The AdminCreate");
			json.put("superpower", "Create all");
			json.put("dateOfBirth", "1995-09-29"); 
			json.put("isAdmin", "false");
			httpRequest.header("Content-Type","application/json");
			httpRequest.body(json.toString()); 
			Response response = httpRequest.request(Method.POST,"");
			String output = response.getBody().asString(); 
			System.out.println( "ouput" +output);
			int statusCode = response.getStatusCode(); 
			System.out.println( "statusCode----" +statusCode);
			
		}
	
		
		
		public void UpdateUserInfoPUT()
		{	
			RestAssured.baseURI ="http://localhost:8081/api/v1/users"; 
			RequestSpecification httpRequest= RestAssured.given().auth().preemptive().basic("admin","power");
			httpRequest.header("Content-Type","application/json"); 
				JSONObject json = new JSONObject();  
				json.put("id", "2"); 
				json.put("email", "dev@somewhere.com");
				json.put("username", "dev"); 
				json.put("password", "dev1");
				json.put("name", "The Dev");
				json.put("superpower", "Code and debug");
				json.put("dateOfBirth", "1995-09-09");
				json.put("isAdmin", "false");
				httpRequest.header("Content-Type","application/json");
				httpRequest.body(json.toString()); 
				Response response = httpRequest.request(Method.PUT,"");
				String output = response.getBody().asString(); 
				System.out.println( "ouput" +output);
				int statusCode = response.getStatusCode(); 
				System.out.println( "statusCode" +statusCode);
		}
		
		
		public void DELUserAccount()
		{	
			
			RestAssured.baseURI = "http://localhost:8081/api/v1/users"; 
			RequestSpecification httpRequest= RestAssured.given().auth().preemptive().basic("admin","power");
			httpRequest.header("Content-Type","application/json"); 
				JSONObject json = new JSONObject();  
				json.put("id", "3"); 
				json.put("email", "tester20@somewhere.com");
				json.put("username", "tester20"); 
				json.put("password", "admin1"); 
				json.put("name", "The AdminCreate");
				json.put("superpower", "Test.");
				json.put("dateOfBirth", "2014-07-15"); 
				json.put("isAdmin", "false");
				httpRequest.header("Content-Type","application/json");
				httpRequest.body(json.toString()); 
				Response response = httpRequest.request(Method.DELETE,"");
				String output = response.getBody().asString(); 
				System.out.println( "ouput" +output);
				int statusCode = response.getStatusCode(); 
				System.out.println( "statusCode------" +statusCode);
		}
			
		}
		

