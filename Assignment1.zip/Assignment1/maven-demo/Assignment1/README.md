# Assignment
REST backend implementation that deals with the creation of accounts, login, updating accounts, deleting accounts, and authorization for different roles.
